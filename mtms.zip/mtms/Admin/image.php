
<?php
if(isset($_POST['submit'])){
	

$filename=$_FILES['upload']['name'];


$tempname=$_FILES['upload']['tmp_name'];
$folder="Img/".$filename;

move_uploaded_file($tempname,$folder);
echo '<img src="'.$folder.'" >';
}
?>
    





 <!DOCTYPE html>
<html>
<head></head>  
<body>
<form action="" method="post" enctype="multipart/form-data">
<input type="file" name="upload">
<input type="submit" name="submit"></form>
</body>
</html>