<!DOCTYPE html>
<html>
<head>

<link rel="stylesheet"href="https:maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https:ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https:cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https:maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>



<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}



.dashboard{display:flex;}

a {
  cursor: pointer;
}

nav {
  width: 250px;
  background: ;
}

nav header {
  position: relative;
  height: 70px;
  padding: 15px 0 0 15px;
  font-size: 16px;
  color: #fff;
  border-bottom: 1px solid blue;
  background: blue;
}

nav header span {
  position: relative;
  display: inline-block;
  width: 36px;
  height: 36px;
  margin: 0 10px 0 0;
  vertical-align: middle;
  border: 1px solid #fff;
}



nav ul li:first-child {
  padding: 15px;
  color: rgba(255,255,255,.5);
  text-transform: uppercase;
  border-bottom: 1px solid @blue-l;
}

nav ul a {
  position: relative;
  display: block;
  padding: 15px 15px 17px 50px;
  color: #fff;
  border-bottom: 1px solid @blue-l;
}

nav ul a:hover,
nav ul a.active {
  background: @blue-l;
}




main {
  flex: 1;
  padding: 25px;
  background: #f5f5f5;
}

main h1 {
  height: 70px;
  margin: -25px -25px 25px -25px;
  padding: 0 25px;
  line-height: 66px;
  font-size: 28px;
  font-weight: 300;
  text-transform: uppercase;
  border-bottom: 1px solid #ddd;
  background: #fafafa;
}

.flex-grid {
  display: flex;
  min-height: 180px;
}

.flex-grid div {
  flex: 1;
  margin: 0 20px 20px 0;
  border: 1px solid #ddd;
  background: #fff;
}

.flex-grid div:last-child {
  margin-right: 0;
}

.flex-grid div h2 {
  padding: 12px 15px;
  font-size: 16px;
  font-weight: 300;
  text-transform: uppercase;
  border-bottom: 1px solid #ddd;
  background: #fafafa;
}
</style>

</head>
<body>
<div class="dashboard">
<nav>
  
  <header>
    <span></span>
   
    <a></a>
  </header>
  
  <ul>
    <li>Navigation</li>
    <li><a class="active">Dashboard</a></li>
    <li><a>Statistics</a></li>
    <li><a>Milestones</a></li>
    <li><a>Tickets</a></li>
    <li><a>GitHub</a></li>
    <li><a>FAQ</a></li>
    <li><a>Settings</a></li>
  </ul>
  
</nav>

<main>
  
  <h1>Dashboard</h1>
  
  <div class="flex-grid">
    
    <div>
      <h2>Headline</h2>
    </div>
    
    <div>
      <h2>Headline</h2>
    </div>
    
    <div>
      <h2>Headline</h2>
    </div>
    
  </div>
  
  <div class="flex-grid">
    
    <div>
      <h2>Headline</h2>
    </div>
    
    <div>
      <h2>Headline</h2>
    </div>
    
  </div>
  
  <div class="flex-grid">
    
    <div>
      <h2>Headline</h2>
    </div>
    
  </div>
  
</main>
</div>
</body>
</html>
    