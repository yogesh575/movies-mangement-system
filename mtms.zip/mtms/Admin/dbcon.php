<?php


$conn = mysqli_connect('localhost','root','','mmts');
if(!$conn){ echo "not connected";}
?>