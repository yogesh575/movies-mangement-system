<?php

include("dbcon.php"); ?>

<form action="generate-pdf.php" method="post">
<input type="submit" ></form>

	
	