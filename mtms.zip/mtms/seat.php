<?php
include("dbcon.php"); 

if(isset($_POST['submit'])){
	if(!empty($_POST['seat'])){
		
		$cont=count($_POST['seat']);
		echo "you select".$cont."<br>";
	
		$row=$_POST['seat'];
		$col=implode(",",$row);
		echo $col;
		$sql="update seat set seat='".$col."' where id=100";
		if(mysqli_query($conn,$sql)){
			echo "updated";
		}
		else{
			echo mysqli_error($conn);
		}
	}
else{
	echo "pls select";
}
}
?>
	<!DOCTYPE html>
 <html> 
 <head>
 <style>
 
 .check{ 
 	display:inline-block;
 	cursor:pointer;
 	font-size:22px;
 }
 .check input{
	display:none;
}
.mark{
	display:inline-block;
	width:80px;
	height:80px;
	box-sizing:border-box;
	background-image:url('chair.png');
	padding:20px;
	margin:5px;
	font-size:30px;
	
}
.check input:checked + .mark{
	background:green;
} 
 
 
 
 .line{ display:inline-block;
 	margin-left:20px;
 }
 .vline{
 	margin-top:20px;
 }
 
 
 .screen{
 	width:150px;
 	border:2px solid black;
 	margin-top:50px;
 	margin-left:70px;
 }
.main input[type="submit"]{
 border:none;
 	color:white;
 	background-color:purple;
 	width:80px;
 	height:40px;
 	margin-top:30px;
 	margin-left:90px;
 	border-radius:10px;
 }
 
</style> 
<script>


function change(a) {
if(a.className == "mark"){
	a.className="mark1";

}
else{

a.className="mark";}
 
}



</script>
  </head> <body>
   <div class="container"> 
   	<div class="main"> 
   	 <form action="seat.php" method="post">
   	  <p class="heading">Select Your Seat
   	  </p> 
   	  <label class="check">
   	  <input type="checkbox" name="seat[]" value="1" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">1</span> </label>
   	<label class="check">
   	  <input type="checkbox" name="seat[]" value="2" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">2</span> </label>
   	 <label class="check">
   	  <input type="checkbox" name="seat[]" value="3" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">3</span></label>
   	   
   	         <div class="line"></div>
   	   
   	   <label class="check">
   	   <input type="checkbox" name="seat[]" value="4" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">4</span> </label>
   	  <label class="check">
   	   <input type="checkbox" name="seat[]" value="5" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">5</span></label>
   	    <label class="check">
   	      <input type="checkbox" name="seat[]" value="6"<?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">6</span></label>
   	   <br>
   	
   	   
   	   <label class="check">
   	  <input type="checkbox" name="seat[]" value="7" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">7</span> </label>
   	<label class="check">
   	  <input type="checkbox" name="seat[]" value="8" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">8</span> </label>
   	 <label class="check">
   	  <input type="checkbox" name="seat[]" value="9" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">9</span></label>
   	  
   	        <div class="line"></div>
   	  
   	  
   	   <label class="check">
   	   <input type="checkbox" name="seat[]" value="10" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">10</span> </label>
   	  <label class="check">
   	   <input type="checkbox" name="seat[]" value="11" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">11</span></label>
   	    <label class="check">
   	      <input type="checkbox" name="seat[]" value="12" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">12</span></label>
   	   <br>
   	   <label class="check">
   	  <input type="checkbox" name="seat[]" value="13" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">13</span> </label>
   	<label class="check">
   	  <input type="checkbox" name="seat[]" value="14" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">14</span> </label>
   	 <label class="check">
   	  <input type="checkbox" name="seat[]" value="15" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">15</span></label>
   	
   	      <div class="line"></div>
   	
   	   <label class="check">
   	   <input type="checkbox" name="seat[]" value="16" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">16</span> </label>
   	  <label class="check">
   	   <input type="checkbox" name="seat[]" value="17" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">17</span></label>
   	    <label class="check">
   	      <input type="checkbox" name="seat[]" value="18" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">18</span></label>
   	   <div class="vline"></div>
   	
   	   <label class="check">
   	  <input type="checkbox" name="seat[]" value="19" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">19</span> </label>
   	<label class="check">
   	  <input type="checkbox" name="seat[]" value="20" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">20</span> </label>
   	 <label class="check">
   	  <input type="checkbox" name="seat[]" value="21" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">21</span></label>
   	      <div class="line"></div>
   	
   	
   	   <label class="check">
   	   <input type="checkbox" name="seat[]" value="22"
	   <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark"onclick="change(this)">22</span> </label>
   	  <label class="check">
   	   <input type="checkbox" name="seat[]" value="23" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">23</span></label>
   	    <label class="check">
   	      <input type="checkbox" name="seat[]" value="24" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">24</span></label>
   	   
   	   <br>
   	   
   	   <label class="check">
   	  <input type="checkbox" name="seat[]" value="25" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">25</span> </label>
   	<label class="check">
   	  <input type="checkbox" name="seat[]" value="26" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">26</span> </label>
   	 <label class="check">
   	  <input type="checkbox" name="seat[]" value="27" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	  <span class="mark" onclick="change(this)">27</span></label>
   	
   	      <div class="line"></div>
   	
   	   <label class="check">
   	   <input type="checkbox" name="seat[]" value="28" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">28</span> </label>
   	  <label class="check">
   	   <input type="checkbox" name="seat[]" value="29" <?php if(in_array("2",$check)){
	echo "checked";
}?>>
   	   <span class="mark" onclick="change(this)">29</span></label>
   	    <label class="check">
   	      <input type="checkbox" name="seat[]" value="30" <?php if(in_array("2",$check)){
	echo "checked";
}?>  >
   	   <span class="mark" onclick="change(this)">30</span></label>
   	   <div class="screen"></div>
   	   <input type="submit" name="submit" Value="Submit"/>
   	    </form> </div> </div> </body> </html>
    
    
		
		
			

    
    
    