<?php


$conn = mysqli_connect('localhost','root','','mmts');
if(!$conn){ echo "not connected";}

$sql = "SELECT * FROM movies where id='".$_POST['id']."'";
$result = mysqli_query($conn, $sql);
if (isset($_POST['id'])){
	 while($row = mysqli_fetch_assoc($result)){
	
	echo $row['name'];
	echo $row['certificate'];
	echo $row['language'];
	echo $row['type'];
	echo $row['duration'];
	echo $row['Casting'];
	echo $row['director'];
	echo $row['description'];
	echo $row['date'];
	
	

	
	 }
	
	
	
}
else{echo "errrrorororor";}
?>