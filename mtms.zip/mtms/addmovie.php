<?php echo'<!DOCTYPE html>
<html>
<head>
</head>

<style>
*{margin:0;padding:0px;}
body{

background-color:#f2bff2;}
.title h1 {

letter-spacing:5px;
font-size:5em;
font-family:sans-serif;
color:purple;
background-color:white;
} 

.title h3 {
padding:10px;
font-size:2em;
background-color:white;
font-family:sans-serif;
color:purple;

} 
nav { width:100%;
background-color:skyblue;
overflow:auto;
}
	

nav ul { list-style:none;
         margin:0px;
     line-height:50px;
padding:0px;
}
  
 nav ul li a{ color:black;
 padding:10px;
 float:left ;
 display:block;
 text-align:center;
 font-size:25px;
 text-decoration:none;
 margin-left:10px;
 
 
		}
  nav ul li:hover{ background:white;} 
nav ul li:hover a{ color:red;}
header h2 {
padding:10px;
font-size:2em;
font-family:sans-serif;
color:white;
margin-top:20px;
margin-bottom:30px;
background-color:purple;
padding-left:40%;

} 	.sidebar{float:right;

margin-top:20px;	
margin-right:50px;	
	 width:40vh;
	 height:100vh;
	 border:2px solid black;
}
.sidebar img{ width:100%;
height:50%;
}
	
	table{margin-left:20%;}
	form label{
	margin-left:10px;
	padding:5px;
	color:black;
	font-size:25px;
	
	
	}
form input[type="text"],input[type="number"],input[type="email"],select{
outline:none;
border: 2px solid purple;
height:35px;
width:300px;
border-radius:5px;
font-size:25px;
margin:10px;		

}
textarea {outline:none;
border: 2px solid purple;
height:200px;
width:300px;
border-radius:5px;

margin:10px;		
}

form input[type="submit"],input[type="reset"]{
background-color:purple;
color:white;
width:200px;
height:40px;
margin:20px;
border-radius:5px;
border:none;

}

</style>



<body>

<header>
	<div class="title">
	<h1>MOVIES TICKET<br> MANAGEMENT SYSTEM</h1>
	<h3>Online Movies Ticket Booking</h3>
	</div>
		<nav>
		<ul>
			<li><a href="#">Home</a></li>
			<li><a href="#">All Movies</a></li>
			<li><a href="#">Booking</a></li>
			<li><a href="#">Update</a></li>
			<li><a href="#">History</a></li>
			<li><a href="#">Logout</a></li>
		</ul>
		</nav>
		<h2>Add Movie</h2>
</header>
<div class="container"><form action="open.php" method="post">
<div class="sidebar"><img src="img/M1.jpg">
<img src="img/U1.jpg">
		
		
		</div>
<form>
<table>

<tr><td><label>Movie Name</label></td>
<td><input type="text"></td></tr>
<tr><td><label>Movie Certificate</label></td>
<td><select>
<option>U/A</option>
<option>U</option>
<option>A</option>
</select></td></tr>
<tr><td><label>Movie Language</label></td>
<td><select>
<option>English</option>
<option>Hindi</option>
<option>Tamil</option>

</select></td></tr>
<tr><td><label>Movie Type</label></td>
<td><input type="text"></td></tr>
<tr><td><label>Duration</label></td>
<td><input type="number"></td></tr>
<tr><td><label>Director</label></td>
<td><input type="text"></td></tr>
<tr><td><label>Casting</label></td>
<td><input type="text"></td></tr>
<tr><td><label>Release Date</label></td>
<td><input type="text"><br>
<tr><td><label>Trailer</label></td>
<td><input type="text"></td></tr>
<tr><td><label>Description</label></td>
<td><textarea cols="20" rows="4"></textarea></td></tr>
<tr><td><label>Photo</label></td>
<td><input type="file"></td></tr>
<tr><td><input type="submit" value="Add Movie"></td>
<td><input type="reset" value="Rest Movie"></td></tr>
</table>
</body>
</html>';
?>