-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 04, 2019 at 05:11 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mmts`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE IF NOT EXISTS `booking` (
  `sid` int(5) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `seatno` varchar(255) NOT NULL,
  `noofseat` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=95460 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`sid`, `time`, `seatno`, `noofseat`, `price`) VALUES
(95459, '2019-08-28 05:15:30', 'A1,B2,A3,A4', 3, 600);

-- --------------------------------------------------------

--
-- Table structure for table `hall1`
--

DROP TABLE IF EXISTS `hall1`;
CREATE TABLE IF NOT EXISTS `hall1` (
  `seatnumber` varchar(432) NOT NULL,
  `name` varchar(432) DEFAULT 'notbooked',
  `email` varchar(432) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hall1`
--

INSERT INTO `hall1` (`seatnumber`, `name`, `email`, `date`) VALUES
('A1', 'notbooked', NULL, '2019-08-21'),
('A2', 'notbooked', NULL, '2019-08-21'),
('A3', 'notbooked', NULL, '2019-08-21'),
('A1', 'notbooked', NULL, '2019-08-21'),
('A2', 'notbooked', NULL, '2019-08-21'),
('A3', 'notbooked', NULL, '2019-08-21'),
('A1', 'notbooked', NULL, '2019-08-21'),
('A2', 'notbooked', NULL, '2019-08-21'),
('A3', 'notbooked', NULL, '2019-08-21'),
('A1', 'notbooked', NULL, '2019-08-21'),
('A2', 'notbooked', NULL, '2019-08-21'),
('A3', 'notbooked', NULL, '2019-08-21'),
('A4', 'notbooked', NULL, '2019-08-21'),
('A5', 'notbooked', NULL, '2019-08-21'),
('A6', 'santosh', 'santu@gmail.com', '2019-08-02'),
('A7', 'santosh', 'santu@gmail.com', '2019-08-02'),
('A8', 'santosh', 'santu@gmail.com', '2019-08-02'),
('B1', 'notbooked', NULL, '2019-08-21'),
('B2', 'notbooked', NULL, '2019-08-21'),
('B3', 'notbooked', NULL, '2019-08-21'),
('B4', 'notbooked', NULL, '2019-08-21'),
('B5', 'notbooked', NULL, '2019-08-21'),
('B6', 'santosh', 'santu@gmail.com', '2019-06-11'),
('B7', 'notbooked', NULL, '2011-01-01'),
('B8', 'notbooked', NULL, '2011-01-01'),
('C1', 'notbooked', NULL, '2019-08-21'),
('C2', 'notbooked', NULL, '2019-08-21'),
('C3', 'notbooked', NULL, '2019-08-21'),
('C4', 'notbooked', NULL, '2019-08-21'),
('C5', 'notbooked', NULL, '2019-08-21'),
('C6', 'santosh', 'santu@gmail.com', '2019-08-02'),
('C7', 'notbooked', NULL, '2011-01-01'),
('C8', 'notbooked', NULL, '2011-01-01'),
('D1', 'notbooked', NULL, '2019-08-21'),
('D2', 'notbooked', NULL, '2019-08-21'),
('D3', 'notbooked', NULL, '2019-08-21'),
('D4', 'notbooked', NULL, '2019-08-21'),
('D5', 'notbooked', NULL, '2019-08-21'),
('D6', 'santosh', 'santu@gmail.com', '2019-08-02'),
('D7', 'notbooked', NULL, '2011-01-01'),
('D8', 'santosh', 'santu@gmail.com', '2019-06-13'),
('A8', 'santosh', 'santu@gmail.com', '2019-08-02'),
('A8', 'santosh', 'santu@gmail.com', '2019-08-02');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
CREATE TABLE IF NOT EXISTS `movies` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `certificate` varchar(30) NOT NULL,
  `language` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `duration` int(10) NOT NULL,
  `Casting` varchar(256) NOT NULL,
  `director` varchar(50) NOT NULL,
  `description` varchar(1024) NOT NULL,
  `date` date NOT NULL,
  `trailor` varchar(1024) NOT NULL,
  `img` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=207 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`id`, `name`, `certificate`, `language`, `type`, `duration`, `Casting`, `director`, `description`, `date`, `trailor`, `img`) VALUES
(201, 'sahoo', 'u', 'hindi', 'Action,Thriller', 120, ' Prabhas, Shraddha Kapoor, Jackie Shroff', ' Sujeeth', 'The Story is about a power battle which is taking place in the higher echelons of power unrelated and unconnected episodes occurring in different parts of the globe, Intertwine in an unforeseen manner to a revelation of mind games. The story delves the audience into the game of a brilliant master mind to reveal the true nature of all that are involved. It challenges the perceptions of who is the hunter and who is the hunted. It blends in a thrilling story with commercial elements of story telling to deliver a high octane action entertainer appealing to all segments of the audience.', '2019-08-30', '', 'img/M1.jpg'),
(203, 'Mission mangal', 'U', 'Hindi', 'Drama,histroy', 130, ' Akshay Kumar, Vidya Balan, Sonakshi Sinha ', ' Jagan Shakti', 'Based on true events of the Indian Space Research Organisation (ISRO) successfully launching the Mars Orbiter Mission (Mangalyaan), making it the least expensive mission to Mars.', '2019-08-15', '', 'Img/M2.jpg'),
(204, 'Batla House', 'U/A', 'Hindi', ' Action, Drama, Thriller ', 156, 'John Abraham, Mrunal Thakur, Ravi Kishan', 'Nikkhil Advani', 'After a deadly encounter, a police officer works to prove that the police acted lawfully.', '2019-09-15', '', 'img/U4.jpg'),
(206, ' Chhichhore', 'U/A', 'Hindi', 'Comedy, Drama', 120, ' Sushant Singh Rajput, Shraddha Kapoor, Varun Sharma', ' Nitesh Tiwari', 'Following a group of friends from university as they progress into middle-age life and go their own separate ways.', '2019-09-06', '', 'img/M3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `pid` int(5) NOT NULL AUTO_INCREMENT,
  `cardname` varchar(256) NOT NULL,
  `cardno` varchar(50) NOT NULL,
  `cardtype` varchar(30) NOT NULL,
  `expdate` varchar(255) NOT NULL,
  `year` int(20) NOT NULL,
  `mobile` int(10) NOT NULL,
  `cvv` varchar(256) NOT NULL,
  `amount` varchar(50) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pid`, `cardname`, `cardno`, `cardtype`, `expdate`, `year`, `mobile`, `cvv`, `amount`) VALUES
(1, 'ruuuyyt', '4545', 'hjhjhjgh', 'Nov', 5210, 1564353, '411', '200'),
(2, 'ruuuyyt', '4545', 'hjhjhjgh', 'Nov', 5210, 1564353, '411', '200'),
(3, 'fdhnhgd', '54545', 'visa', 'Jan', 2222, 254645654, '012', '45321');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `mob` varchar(20) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Hno` varchar(30) NOT NULL,
  `Phn` int(10) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zip` int(10) NOT NULL,
  `state` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `pwd`, `mob`, `Email`, `Hno`, `Phn`, `city`, `zip`, `state`, `address`) VALUES
(1, 'yogesh', 'efewr', '465435465456', 'ewewr@gmail.com', '546', 564, '56456', 252, 'rtretre', 'ertbrjkgjkfdvdfvc'),
(2, 'gaurav', 'gaurav', '9990871636', 'gaurav@gmail.com', 'b1/532 ', 11100, 'jhadfuk', 1, 'leja', 'mat puch'),
(3, 'yogesh', '564564', '4545656565', 'rr@gmail.com', 'b-63', 534564545, 'delhi', 110086, 'derhi', 'ghwkerlgjfelakhgeanlivbtuiveoer\r\nsdfnmsahcgfgvfskdfhvd\r\nsbfshfkjssdfaskddfs');

-- --------------------------------------------------------

--
-- Table structure for table `seat`
--

DROP TABLE IF EXISTS `seat`;
CREATE TABLE IF NOT EXISTS `seat` (
  `sid` int(10) NOT NULL AUTO_INCREMENT,
  `seatno` varchar(20) NOT NULL,
  `rowId` varchar(20) NOT NULL,
  `columnId` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seat`
--

INSERT INTO `seat` (`sid`, `seatno`, `rowId`, `columnId`, `status`) VALUES
(102, '', 'A', '1', 0),
(103, '', 'A', '2', 0),
(104, '', 'A', '3', 0),
(105, '', 'A', '4', 0),
(106, '', 'A', '5', 0),
(107, '', 'B', '1', 0),
(108, '', 'B', '2', 0),
(109, '', 'B', '3', 0),
(110, '', 'B', '4', 0),
(111, '', 'B', '5', 0),
(112, '', 'C', '1', 0),
(113, '', 'C', '2', 0),
(114, '', 'C', '3', 0),
(115, '', 'C', '4', 0),
(116, '', 'C', '5', 0),
(117, '', 'D', '1', 0),
(118, '', 'D', '2', 0),
(119, '', 'D', '3', 0),
(120, '', 'D', '4', 0),
(121, '', 'D', '5', 0),
(122, '', 'E', '1', 0),
(123, '', 'E', '2', 0),
(124, '', 'E', '3', 0),
(125, '', 'E', '4', 0),
(126, '', 'E', '5', 0);

-- --------------------------------------------------------

--
-- Table structure for table `upcoming`
--

DROP TABLE IF EXISTS `upcoming`;
CREATE TABLE IF NOT EXISTS `upcoming` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(30) NOT NULL,
  `relese` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
