<?php
   include("dbcon.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = $_POST['username'];
      $mypassword = $_POST['password']; 
      
      $sql = "SELECT * FROM register WHERE name = '".$myusername."' and pwd = '".$mypassword."'";
      $result = mysqli_query($conn,$sql);
      $row = mysqli_fetch_array($result);
 
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
        // session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("location: welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   
   <head>
      <title>Login Page</title>
      
     
      
   </head>
   
   <body >
	
      
       
            <div><b>Login</b></div>
				
            <div>
               
               <form action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name = "username" /><br /><br />
                  <label>Password  :</label><input type = "password" name = "password"  /><br/><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>
               
               <?php if(isset($error)){echo $error;} ?></div>
					
           
				
         
			
      

   </body>
</html>