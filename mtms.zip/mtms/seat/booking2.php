<?php 
session_start();
error_reporting(0);
include('dbcon.php');
$user = $_SESSION['login_user'];
if($user==true){}
else{
	
	header('location:../login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Booking</title>
	<style>
	
	
       body {
    margin:0px;
    padding:0px;
    font-family: sans-serif;
		background-image:url('../image/back.jpg');
		}   
		.title h1 {

letter-spacing:5px;
font-size:5em;
font-family:sans-serif;
background-color:white;
color:purple;

} 

.title h3 {
padding:10px;
font-size:2em;
font-family:sans-serif;
background-color:white;
color:purple;

} 
nav { width:100%;
background-color:skyblue;
overflow:auto;
}
	

nav ul { list-style:none;
         margin:0px;
     line-height:50px;
padding:0px;
}
  
 nav ul li a{ color:black;
 padding:10px;
 float:left ;
 display:block;
 text-align:center;
 font-size:25px;
 text-decoration:none;
 margin-left:10px;
 
 
		}
  nav ul li:hover{ background:white;} 
nav ul li:hover a{ color:red;}

header h2 {
padding:10px;
font-size:2em;
font-family:sans-serif;
color:white;
margin-top:20px;
margin-bottom:30px;
background-color:purple;
padding-left:40%;

} 	
		
	.cinema{
		
		border:2px solid black;
		background-color:white;
		width:80%;
		margin: 10px auto;
		padding:10px 200px;
	box-sizing: border-box;
	}
	form input[type="submit"],input[type="reset"]{
background-color:purple;
color:white;
width:200px;
height:40px;
margin:20px;
border-radius:5px;
border:none;

}
	
	
	
	
	</style>
</head>
<body>
<header>
	<div class="title">
	<h1>MOVIES TICKET<br> MANAGEMENT SYSTEM</h1>
	<h3>Online Movies Ticket Booking</h3>
	</div>
		<nav>
		<ul>
			<li><a href="home.php">Home</a></li>
			<li><a href="showmovies.php">All Movies</a></li>
			<li><a href="#">Booking</a></li>
			<li><a href="#">Update</a></li>
			<li><a href="#">History</a></li>
			<li><a href="#">Logout</a></li>
		</ul>
		</nav>
	
</header>
<div class="cinema">
<form action="../payment.php" method="post" name="aform">

<input type="hidden" name="test"></input>

	A1<img src="seat-empty.png" id= "a1" class="seats" height="100em" name="a1">
	A2<img src="seat-empty.png" id= "a2" class="seats" height="100em" name="a2">
	A3<img src="seat-empty.png" id= "a3" class="seats" height="100em" name="a3">
	A4<img src="seat-empty.png" id= "a4" class="seats"  height="100em" name="a4">
	A5<img src="seat-empty.png" id= "a5" class="seats" height="100em" name="a5"><br>
	B1<img src="seat-empty.png" id= "b1" class="seats" height="100em" name="b1">
	B2<img src="seat-empty.png" id= "b2" class="seats" height="100em" name="b2">
	B3<img src="seat-empty.png" id= "b3" class="seats" height="100em" name="b3">
	B4<img src="seat-empty.png" id= "b4" class="seats" height="100em" name="b4">
	B5<img src="seat-empty.png" id= "b5" class="seats" height="100em" name="b5"><br>
	C1<img src="seat-empty.png" id= "c1" class="seats" height="100em" name="c1">
	C2<img src="seat-empty.png" id= "c2" class="seats" height="100em" name="c2">
	C3<img src="seat-empty.png" id= "c3" class="seats" height="100em" name="c3">
	C4<img src="seat-empty.png" id= "c4" class="seats" height="100em" name="c4">
	C5<img src="seat-empty.png" id= "c5" class="seats" height="100em" name="c5"><br>
	D1<img src="seat-empty.png" id= "d1" class="seats" height="100em" name="d1">
	D2<img src="seat-empty.png" id= "d2" class="seats" height="100em" name="d2">

	D3<img src="seat-empty.png" id= "d3" class="seats" height="100em" name="d3">
	D4<img src="seat-empty.png" id= "d4" class="seats" height="100em" name="d4">	
	D5<img src="seat-empty.png" id= "seats" class="seats" height="100em" name="d5">
<br>
	
	
	
	
<input type="submit">
<input type="reset"></form>
</div>
</body>
<script type="text/javascript">
	var seatBooked = ["a1", "b2","a3", "a4"];
	var seatRows = ["a", "b" , "c" , "d"];

	printSeats(seatBooked,seatRows);
	function printSeats(seatBooked,seatRows) {
		for (var i = 0; i < seatRows.length; i++) {
			// --------      I have assumed that there is 5 seats in a row     ----------
			for (var j = 1; j < 6	; j++) {
				
				var currentSeat = seatRows[i] + j;
				var IsSeatBooked = false;
				for (var k = 0; k < seatBooked.length; k++) 
				{
								
							if (currentSeat == seatBooked[k])
								{
								IsSeatBooked = true;
						
								}
				}
				if (IsSeatBooked == true) {
				
			document.getElementById(currentSeat	).src = "seat-booked.png";
				}
				else{
			//		document.getElementById(currentSeat	).src = "seat-selected.png";}
					
				
			var click = document.getElementById(currentSeat).addEventListener("click",function change()
		{	console.log(currentSeat);
			var a =  document.getElementById(currentSeat);
					if(a.src.match('empty'))
					{
						a.src = "seat-selected.png";
						i = a.name;
	
		
		aform.test.value = aform.test.value + i;
					}
					else{
						a.src = "seat-empty.png";
						}
			
		});
					
							
		}}
		}
	}

</script>
</html>