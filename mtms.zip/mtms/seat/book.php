<!DOCTYPE html>
<html>
<head>
<script>

function change(a) {
	 var i;
	 
	if(a.src.match('empty')){
		a.src = "seat-selected.png";
		i = a.name;
	console.log(i);
		
		aform.test.value = aform.test.value + i + ",";
	} 
	else{
		a.src = "seat-empty.png";
	
 	
}}


function booked(b){
	//document.getElementById("A1");
	
var a  =["a","b","c","d"];
if(a=="a")
{
	b.src="seat-booked.png"
}}
/*
function booked(){
	if(A1.src="seat-selected.png")
	{A1.src="seat-booked.png"}

}
*/




</script>
<style>
form{
margin:100px;
margin-left:20%;
}
</style>

<?php  

if (!empty($_POST))
{$seat=$_POST['test'];
echo 'seat = '.$seat;
}
//$booked[$i] = $seat;
//$i++;

else
{//$booked = array();
 //static $i=0;
 $seat=0;
 echo 'first seat = '.$seat;
}
?>


</head>
<body><form action="booking.php" method="post" name="aform">
<input type="text" name="test"></input>
<h1 id="title">Hi</h1>
<img id="A1" src="seat-empty.png" height="100em"  onclick="change(this)"  onload="booked(b)" name="a" value="11" alt="A">
<img src="seat-empty.png" height="100em"  onclick="change(this)" name="b" onloaad="seat(this)" value="12"alt="empty">
A<img src="seat-empty.png" height="100em" onclick="change(this)" name="c" onloaad="seat(this)" alt="empty">
A<img src="seat-empty.png" height="100em" onclick="change(this)" name="d" onloaad="seat(this)" alt="empty">
A<img src="seat-empty.png" height="100em" onclick="change(this)" name="e" onloaad="seat(this)" alt="empty"><br>
B<img src="seat-empty.png" height="100em" onclick="change(this)" name="f" alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty"><br>
C<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty"><br>
D<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty"><br>
E<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty"><br>
<input type="submit"></form>
</body>
</html>



