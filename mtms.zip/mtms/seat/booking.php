<!DOCTYPE html>
<html>
<head>
<script>
function change(a) {
	 var i='test';
	if(a.src.match('empty')){
		a.src = "seat-selected.png";
		i = a.name;
	
		
		aform.test.value = aform.test.value + i;
	}
	else{
		a.src = "seat-empty.png";
			
 	}
}
</script>
<style>
form{
margin:100px;
margin-left:20%;
}
</style>

<?php  

if (!empty($_POST))
{$seat=$_POST['test'];
echo 'seat = '.$seat;
}
//$booked[$i] = $seat;
//$i++;

else
{//$booked = array();
 //static $i=0;
 $seat=0;
 echo 'first seat = '.$seat;
}
?>


</head>
<body><form action="booking.php" method="post" name="aform">
<input type="text" name="test"></input>
<img src="seat-empty.png" height="100em"  onclick="change(this)" name="a" value="11" alt="A">
<img src="seat-empty.png" height="100em"  onclick="change(this)" name="a" value="12"alt="empty">
A<img src="seat-empty.png" height="100em" onclick="change(this)"  name="a" alt="empty">
A<img src="seat-empty.png" height="100em" onclick="change(this)"  name="a" alt="empty">
A<img src="seat-empty.png" height="100em" onclick="change(this)"  name="a" alt="empty"><br>
B<img src="seat-empty.png" height="100em" onclick="change(this)"  name="b" alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  name="b" alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  name="b" alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"   name="b"alt="empty">
B<img src="seat-empty.png" height="100em" onclick="change(this)"  name="b" alt="empty"><br>
C<img src="seat-empty.png" height="100em" onclick="change(this)"  name="c" alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"  name="c" alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"  name="c" alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"   name="c"alt="empty">
C<img src="seat-empty.png" height="100em" onclick="change(this)"   name="c"alt="empty"><br>
D<img src="seat-empty.png" height="100em" onclick="change(this)"   name="d"alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"   name="d"alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  name="d" alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  name="d" alt="empty">
D<img src="seat-empty.png" height="100em" onclick="change(this)"  name="b" alt="empty"><br>
E<img src="seat-empty.png" height="100em" onclick="change(this)"   name="b"alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"   name="b"alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"   name="b"alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"   name="b"alt="empty">
E<img src="seat-empty.png" height="100em" onclick="change(this)"  alt="empty"><br>
<input type="submit"></form>
</body>
</html>



