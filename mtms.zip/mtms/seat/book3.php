<?php

$conn = mysqli_connect('localhost','root','','mmts');
if(!$conn){ echo "not connected";}

  

   $seats = array(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20);
$rows = array('A','B','C','D','E','F','G','H');


   function check_status($seat,$row)
   {
       $query = mysqli_query($conn,"SELECT * FROM seats WHERE columnId = '$seat' AND rowId = '$row'");
       $row = mysqli_fetch_array($query);
       $check = $row['status'];

       if($check >0)
       {
           return 'disabled';
       }
       else{
           return 'available';
       }

   }
foreach($seats as $seat) 
{
   	foreach($rows as $row) 
 {
       ${$row.$seat} = check_status($seat,$row);
 	}
}

if(isset($_POST ['submit']))
{
 	
 	for($a=1; $a <=20;   $a++)
 	{
     if(isset($_POST['ah'.$a]))
     {
     	echo 'A'.$a;
 	echo " ";
     	mysqli_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'A' AND columnId = $a");
     }
 	}

 	
 	for($b=1; $b <=20; $b++)
 	{
     if(isset($_POST['bh'.$b])) 
     {
     	echo 'B'.$b;
 	echo " ";
     	mysqli_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'B' AND columnId = $b");
     }
 	}

 	for($c=1; $c <=20; $c++)
 	{
     if(isset($_POST['ch'.$c]))
     {
     	echo 'C'.$c;
 	echo " ";
     	mysql_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'C' AND columnId = $c");
     }
 	}

 	for($d=1; $d <=20; $d++)
 	{
     if(isset($_POST['dh'.$d])) 
     {
     	echo 'D'.$d;
 	echo " ";
     	mysqli_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'D' AND columnId = $d");
     }
 	}

 	for($e=1; $e <=20; $e++)
 	{
     if(isset($_POST['eh'.$e])) 
     {
     	echo 'E'.$e;
 	echo " ";
     	mysql_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'E' AND columnId = $e");
     }
 	}

 	for($f=1; $f <=20; $f++)
 	{
     if(isset($_POST['fh'.$f])) 
     {
     	echo 'F'.$f;
 	echo " ";
     	mysqli_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'F' AND columnId = $f");
     }
 	}
 
 	for($g=1; $g <=20; $g++)
 	{
     if(isset($_POST['gh'.$g])) 
     {
     	echo 'G'.$g;
 	echo " ";
     	mysqli_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'G' AND columnId = $g");
     }
 	}
 
 	for($h=1; $h <=20; $h++)
 	{
     if(isset($_POST['hh'.$h])) 
     {
     	echo 'H'.$h;
 	echo " ";
     	mysqli_query($conn,"UPDATE seats SET status = 1 WHERE rowId = 'H' AND columnId = $h");
     }
 	}
}

 
?>
<html>
<head>
<style>
ul { list-style: none; margin:0; padding:0; width:auto;}
li {
   display:-moz-inline-stack;
   display:inline-block;
   zoom:1;
   *display:inline;
   min-width: 2em;
}
label {
   display:-moz-inline-stack;
   display:inline-block;
   zoom:1;
   *display:inline;
   min-width: 4em;
}
li label {
   cursor: pointer;
   -webkit-touch-callout: none;
   -webkit-user-select: none;
   -khtml-user-select: none;
   -moz-user-select: none;
   -ms-user-select: none;
   user-select: none;
}
li label:hover input[type=checkbox] {
   outline:2px solid red;
}
div { display:block; }
div.row {
   float:left;
   clear:both;
}
div.submit {
   padding: 50px 0;
   float:none;
   clear:both;
   margin: 20px 0;
   text-align:center;
}
</style>
</head>
<body>
   <form method="post" >
       <p>&nbsp;</p>
       <?php foreach ($seats as $row_id => $columns): ?>
           <div class="row">
               <h1>ROW <?php echo $row_id?></h1>
               <ul>
               <?php foreach ($columns as $seat_num => $col):  // loop seat nums ?>
                   <?php
                       /*
                        * Use hidden input just to hold seat id, this is to handle if checkbox not checked form will not submit the seat_num
                        */
                   ?>
                   <input type="hidden" name="seat_ids[]" value="<?php echo $col['id']?>">
                   <?php $status = !$col['status'] ? 'disabled' : 'available'; ?>
                   <li>
                       <label>
                           <input name="seat_<?php echo $col['id']?>" type="checkbox" id="<?php echo $row_id.$seat_num?>" value="1" <?php echo $col['status'] ? 'checked="checked"' : ''?> onchange="this.value= this.checked ? 1 : 0;">
                           <?php echo $row_id.$seat_num?>
                       </label>
                   </li>
               <?php endforeach; ?>
               </ul>
           </div>
       <?php endforeach; ?>

       <div class="submit">
           <button type="submit">Update Seats</button>
       </div>
   </form>
</body>
</html>