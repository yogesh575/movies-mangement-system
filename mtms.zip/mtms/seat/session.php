<?php
include("dbcon.php");
   session_start();
   $check = $_SESSION['name'];
 $ses_sql = mysqli_query($conn,"select name from register where name = '".$check."' ");
   
   $row = mysqli_fetch_array($ses_sql);
     $login = $row['name'];
	 if($login == $check){
		 echo "done";
	
	 }
  

   
?>