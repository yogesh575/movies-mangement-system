﻿<!DOCTYPE html>
<html lang="en">
<head>



  <style>
 
   



   .wrapper{
      display:grid;
    
      grid-template-columns:repeat(9, 0.5fr);
      grid-gap:1em;
   
      grid-auto-rows: minmax(5px, auto);
	 
    }

     .wrapper1{
      display:grid;
    
      grid-template-columns:repeat(11, 0fr);
      grid-gap:1em;
   
      grid-auto-rows: minmax(5px, auto);
	 
    }

    .wrapper > div{

      padding:0.5em;
    }
    .wrapper > div:nth-child(odd){

    }

   .wrapper > p{
      background:#eee;
      padding:0em;
    }
	
	

}
  </style>
  <script>
  
  function change(a) {
if(a.src.match('empty')){
	a.src = "seat-selected.png";

}
else{

a.src = "seat-empty.png";
 
}
}

  </script>
</head>

<body>


<?php 


include('dbcon.php');
?>

<?php 


if(isset($_GET['var']))
{ 

echo "came";
$a=$_GET['var'];
	
	   $selsql="select * from hall1 where  seatnumber='$a' ";
	   	$result = mysqli_query($conn,$selsql); 
		
		$res=mysqli_fetch_assoc($result);
		
		if($res['name']=="notbooked")
		{
	
	
	
	$name="santosh";
	$email="santu@gmail.com";
	$date=date("Y/m/d");
	
	
	
	
	
	
	
	$time1="B1-1";
 
   $selsql="update hall1 set name='$name',email='$email',date='$date' where seatnumber='$a' ";
	$result = mysqli_query($conn, $selsql); 
	if($result)
	{?>
		<script>
		alert("Booking conform");
		</script>
	<?php 	
	}
	else{ ?>
		<script>
		alert("Alrady booked");
		</script>
	<?php 
		
	}
		}
		else{
			?>
		<script>
		alert("Alrady booked");
		</script>
	<?php 
		}
	
}

?>




  <div class="wrapper">
   
	
<?php 
	for ($i=1;$i<=8;$i++)
{    if($i==5)
	{ ?>
	<div> <img src="1.jpg" height="100em"></div>	

   
		<?php
	}
	?>
   <div >
   
   <a href="book1.php?var=<?php echo $i ; ?>"> A<?php echo $i ?>

	
	
	<?php


$time1="A".$i;
 
   $selsql="select * from hall1 where seatnumber='$time1'";
	$result = mysqli_query($conn, $selsql);  


$res=mysqli_fetch_assoc($result) ;

	if($res['name']=="notbooked")
    

{?>

<img src="seat-empty.png" onclick="change(this)" height="100em">
	<?php }
	else{ ?>
	<img src="seat-booked.png" height="100em">
	<?php }
	
	

	?>
   
   </a>
   
   
   
   
	
    </div>
<?php }?>
	





  
	
<?php 
	for ($i=1;$i<=8;$i++)
{    if($i==5)
	{ ?>
<div> <img src="1.jpg" height="100px"></div>	

   
		<?php
	}
	?>
   <div >
 <a href="book1.php?var=B<?php echo $i ; ?>"> B<?php echo $i ?>

	
	
	<?php


$time1="B".$i;
 
   $selsql="select * from hall1 where seatnumber='$time1'";
	$result = mysqli_query($conn, $selsql);  


$res=mysqli_fetch_assoc($result) ;

	if($res['name']=="notbooked")
    

{?>

<img src="seat-empty.png" onclick="change(this)"height="100px">
	<?php }
	else{ ?>
	<img src="seat-booked.png" height="100px">
	<?php }
	
	

	?>
  </a>  </div>
<?php }?>
	





	
<?php 
	for ($i=1;$i<=8;$i++)
{ 
   if($i==5)
	{ ?>
<div> <img src="1.jpg" height="100px"></div>	
	
   
		<?php
	}
	?>
   <div>
 <a href="book1.php?var=C<?php echo $i ; ?>"> C<?php echo $i ?>

	
	
	<?php


$time1="C".$i;
 
   $selsql="select * from hall1 where seatnumber='$time1'";
	$result = mysqli_query($conn, $selsql);  


$res=mysqli_fetch_assoc($result) ;

	if($res['name']=="notbooked")
    

{?>

<img src="seat-empty.png" onclick="change(this)" height="100px">
	<?php }
	else{ ?>
	<img src="seat-booked.png" height="100px">
	<?php }
	
	

	?>
 </a>   </div>
<?php }?>



    
	
<?php 
	for ($i=1;$i<=8;$i++)
{ 
   if($i==5)
	{ ?>
	<div> <img src="1.jpg" height="100px"></div>	

   
		<?php
	}
	?>
   <div>
	 <a href="book1.php?var=D<?php echo $i ; ?>"> D<?php echo $i ?>

	
	
	<?php


$time1="D".$i;
 
   $selsql="select * from hall1 where seatnumber='$time1'";
	$result = mysqli_query($conn, $selsql);  


$res=mysqli_fetch_assoc($result) ;

	if($res['name']=="notbooked")
    

{?>

<img src="seat-empty.png" onclick="change(this)" height="100px">
	<?php }
	else{ ?>
	<img src="seat-booked.png" height="100px">
	<?php }
	
	

	?>
  </a>  </div>
<?php }?>


	
</div>




  
  
  
 
  
  
  
  <div class="relative">
  <ul id="seatDescription" style="list-style-type:none;" >
									<li><span><img src="seat-empty.png" height="24px"></span> Available Seat</li>
									<li><span><img src="seat-booked.png" height="24px"></span> Booked Seat</li>
									<li><span><img src="seat-selected.png" height="24px"></span> Selected Seat</li>
								</ul>
								</div>
						
</body>
</html>
