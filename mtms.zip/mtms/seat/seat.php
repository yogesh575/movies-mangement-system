<?php
include('dbcon.php');

/*$qry="CREATE TABLE `hall1` (
  `seatnumber` varchar(432) NOT NULL,
  `name` varchar(432) DEFAULT 'notbooked',
  `email` varchar(432) DEFAULT NULL,
  `date` date  NULL
) ";
if (mysqli_query($conn, $qry)) {
    echo "table created successfully w";
} else {
    echo "Error creating table: ".mysqli_error($conn);
}
*/
$qry="INSERT INTO `hall1` (`seatnumber`, `name`, `email`, `date`) VALUES
('A1', 'santosh', 'santu@gmail.com', '2019-05-25'),
('A2', 'santosh', 'santu@gmail.com', '2019-05-25'),
('A3', 'notbooked', NULL, '2011-01-01'),
('A4', 'notbooked', NULL, '2001-02-01'),
('A5', 'notbooked', NULL, '2011-01-01'),
('A6', 'notbooked', NULL, '2011-01-01'),
('A7', 'notbooked', NULL, '2011-01-01'),
('A8', 'notbooked', NULL, '2011-01-01'),
('B1', 'notbooked', NULL, '2011-01-01'),
('B2', 'notbooked', NULL, '2011-01-01'),
('B3', 'santosh', 'santu@gmail.com', '2019-06-06'),
('B4', 'notbooked', NULL, '2011-01-01'),
('B5', 'notbooked', NULL, '2011-01-01'),
('B6', 'santosh', 'santu@gmail.com', '2019-06-11'),
('B7', 'notbooked', NULL, '2011-01-01'),
('B8', 'notbooked', NULL, '2011-01-01'),
('C1', 'notbooked', NULL, '2011-01-01'),
('C2', 'notbooked', NULL, '2011-01-01'),
('C3', 'notbooked', NULL, '2011-01-01'),
('C4', 'notbooked', NULL, '2011-01-01'),
('C5', 'notbooked', NULL, '2011-01-01'),
('C6', 'notbooked', NULL, '2011-01-01'),
('C7', 'notbooked', NULL, '2011-01-01'),
('C8', 'notbooked', NULL, '2011-01-01'),
('D1', 'notbooked', NULL, '2011-01-01'),
('D2', 'notbooked', NULL, '2011-01-01'),
('D3', 'notbooked', NULL, '2011-01-01'),
('D4', 'santosh', 'santu@gmail.com', '2019-05-25'),
('D5', 'notbooked', NULL, '2011-01-01'),
('D6', 'notbooked', NULL, '2011-01-01'),
('D7', 'notbooked', NULL, '2011-01-01'),
('D8', 'santosh', 'santu@gmail.com', '2019-06-13')";
if (mysqli_query($conn, $qry)) {
    echo "table created successfully w";
} else {
    echo "Error creating table: ".mysqli_error($conn);
}
?>