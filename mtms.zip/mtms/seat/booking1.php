<!DOCTYPE html>
<html>
<head>
	<title>Booking</title>
</head>
<body>
	<div id="seats" style="position: absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);"></div>
	<img src="seat-empty.png" id="a1" height="100em"  onclick="change(this)">
	<img src="seat-empty.png" id="a2" height="100em"  onclick="change(this)">
	<img src="seat-empty.png" id="a3" height="100em" onclick="change(this)">
	<img src="seat-empty.png" id="a4" height="100em" onclick="change(this)">
	<img src="seat-empty.png" id="a5" height="100em" onclick="change(this)">
	<img src="seat-empty.png" id="a6" height="100em" onclick="change(this)">
</body>
<script type="text/javascript">
	var seatBooked = ["a1", "b3","d3"];
	var seatRows = ["a","b","c","d"];
	console.log(seatRows.length);
	console.log(seatBooked.length);
printSeats(seatBooked,seatRows);
	function printSeats(seatBooked,seatRows) {
		for (var i = 0; i < seatRows.length; i++ ) {
				console.log(i);
			// --------      I have assumed that there is 5 seats in a row     ----------
			for (var j = 1; j < 6;j++) {
		
				var currentSeat = seatRows[i] + j;
				console.log(currentSeat);
				
				var imgreplace = document.getElementById("a"+j);
				
					imgreplace.src = "seat-booked.png";		
				}
				console.log(i);
			}
	}
	

	
</script>
</html>`